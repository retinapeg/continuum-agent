# CONTINUUM

**Persistent Autonomous Intelligence · v0.1 research prototype**

When should an agent act again after the conversation ends?

CONTINUUM is a dependency-free Python laboratory for comparing reactive, periodic, and adaptive agents over a stream of goals, revisions, cancellations, and deadlines. SQLite preserves observations, memory, task progress, internal state, and action receipts. A virtual clock makes experiments fast and repeatable.

**Research question:** does continuously evolving agent state improve performance on long-horizon tasks compared with reactive and periodically scheduled agents?

**v0.1 finding:** adaptive scheduling completes more goals in this synthetic suite, at higher cost and lower intervention precision. This establishes a scheduling baseline, not a causal demonstration that continuous state or persistent memory improves intelligence. There are no LLM calls, live integrations, messages, or payments.

## Run it

Python **3.11+**; verified here on **Python 3.13.15**. No installation, credentials, or third-party runtime packages required. Run from the repository root:

```sh
# One deterministic experiment
python3 -m continuum demo --policy adaptive --scenario quiet_deadlines --seed 0

# Compare the same environment with a fixed schedule
python3 -m continuum demo --policy periodic --scenario quiet_deadlines --seed 0

# Keep an inspectable database; use a new filename for each run
python3 -m continuum demo --policy adaptive --db results/my-demo.sqlite

# Full reproducible experiment: 30 seeds × 5 regimes × 3 policies
python3 -m continuum benchmark --seeds 30 --output results

# Reliability and metric checks
python3 -m unittest discover -s tests -v
```

The default adaptive demo completes **10/10 feasible goals**, with **10 attempts**, **37 decisions**, **zero latency**, and **13.95 synthetic cost units**. SQLite databases are ignored by Git; CSV/JSON benchmark evidence is included.

Inspect a saved audit using Python's built-in SQLite support:

```sh
python3 - <<'PY'
import sqlite3
with sqlite3.connect('results/my-demo.sqlite') as db:
    for row in db.execute('SELECT at, kind, payload FROM audit ORDER BY seq LIMIT 12'):
        print(row)
PY
```

Reusing a nonempty simulation database is rejected to prevent accidentally mixing experimental runs. The storage layer supports reopen/recovery of memory, task state, and internal state; the simulator does **not** resume a partially completed experiment.

## Architecture

```mermaid
flowchart LR
    S[Seeded scenario generator] --> E[Virtual-time environment]
    E -->|Public observations| I[Transactional event ingestion]
    I --> DB[(SQLite: events, facts, tasks, state)]
    DB --> C[Analytical continuous-time state]
    DB --> P[Shared action policy]
    C --> A[Adaptive scheduler]
    R[Reactive: event arrivals] --> P
    T[Periodic: every 6 units] --> P
    A --> P
    P -->|Attempt| E
    E -->|Success or failure receipt| DB
    P --> L[(Decision and action audit)]
    E -->|Private truth| M[Metric evaluator]
    L --> M
    M --> B[CSV results, paired bootstrap, SHA-256 manifest]
```

**Separate observation from truth.** Agents see estimated readiness and deadlines. Only the environment sees actual readiness. A premature intervention fails and remains in the precision and cost denominators. No scheduler can inspect the private goal oracle.

**Persist before proceeding.** Event insertion, memory/task updates, and the state checkpoint share a SQLite transaction. Identical event deliveries are no-ops; conflicting IDs and backward time are rejected. Action receipts and task updates are atomic. Completed or cancelled tasks cannot be acted on again.

**Simulate continuous time without a busy loop.** Between observations, activation follows the exact solution `a(t + Δ) = a(t) × exp(-0.15 × Δ)`. Goal events add 1.0 activation; fact/cancellation events add 0.1, capped at 10. Adaptive idle intervals are `max(3, ceil(12 / (1 + a)))`. Known readiness times and retry eligibility can cause earlier wakes. The state model accepts fractional time; the environment evaluates events and metrics on integer virtual-time boundaries. This is analytical decay, not continuous neural computation or learning.

All agents ingest the same events into the same memory implementation and use the same deadline-ordered action policy. They attempt every estimated-ready pending task, retrying no sooner than four units after failure. Only the decision clock changes:

| Policy | When it decides |
|---|---|
| Reactive | Once per timestamp with arriving events |
| Periodic | At 6, 12, …, 120; events still update memory immediately |
| Adaptive | On events, at predicted readiness/retry times, or at a state-dependent idle wake; initial wake at 0 |

Fact confidence also decays analytically, `exp(-0.02 × age)`. Explicit expiry removes a fact from recall. Confidence is diagnostic in v0.1; it does not drive action selection.

## Measured results

Actual checked-in run: **450 simulations**, covering **150 matched environments**, seeds **0–29**, five equally weighted regimes, and a **120-unit horizon**. Each environment has 12 proposed goals; some are cancelled or infeasible. Values below are means of per-run metrics, not pooled event ratios.

| Metric | Reactive | Periodic | Adaptive |
|---|---:|---:|---:|
| Feasible goal completion | 82.93% | 73.58% | **94.21%** |
| Memory accuracy | 100.00% | 100.00% | 100.00% |
| Intervention precision | **92.36%** | 90.20% | 88.23% |
| Intervention recall | 82.93% | 73.58% | **94.21%** |
| Mean successful-task latency, virtual units | 1.415 | 1.789 | **0.227** |
| Decision cycles per run | 42.60 | **20.00** | 53.13 |
| Interruptions per run | 8.83 | **8.03** | 10.85 |
| Synthetic cost units per run | 13.56 | **10.50** | 16.63 |

Adaptive's paired completion improvement is **+11.28 percentage points** versus reactive (95% seed-bootstrap interval **9.58–12.84**) and **+20.63 points** versus periodic (**18.22–23.09**). Its additional cost is **+3.07** and **+6.13** units per run respectively. The intervals describe variation across this generator's seeds, not generalization to real users or other tasks.

### Where the benefit disappears

| Regime | Reactive completion | Periodic completion | Adaptive completion |
|---|---:|---:|---:|
| Event-aligned readiness | 100.00% | 77.22% | 100.00% |
| Quiet, narrow deadlines | 60.67% | 70.67% | 100.00% |
| Wide action windows | 100.00% | 100.00% | 100.00% |
| Dense irrelevant fact stream | 100.00% | 70.67% | 100.00% |
| Misleading readiness estimates | 53.97% | 49.33% | 71.03% |

Wide windows erase the completion advantage: periodic costs **12.25** units versus adaptive's **13.99**. Dense events make reactive competitive because unrelated arrivals provide opportunities to check pending work. Misleading estimates reduce adaptive precision to **41.14%**, below reactive's **61.79%** and periodic's **51.00%**. More autonomous activity is not automatically better.

### Metric contract

- **Completion / intervention recall:** distinct successful goals divided by goals with at least one true actionable timestamp before cancellation. Each goal is one intervention opportunity; recall intentionally equals completion here. Empty-opportunity runs score 1.0.
- **Precision:** successful attempts divided by all attempts; undefined (`null`) when no attempts occur.
- **Memory accuracy:** exact latest, unexpired value or correct absence, checked at every timestamp for four known keys and one absent key. Expiry is exclusive; action deadlines are inclusive. This shared-ingestion control is intentionally equal across agents and is dominated partly by absence probes; it is not semantic memory evaluation.
- **Latency:** completion time minus true readiness, averaged only over completed goals. Runs without completions return `null`; aggregate latency excludes those runs. Always interpret latency beside completion to avoid survivorship bias.
- **Interruptions:** decision cycles containing at least one action attempt, including failures. These are simulated action batches, not measured human annoyance. This workload usually has one attempt per batch.
- **Cost:** `0.01 × ingested events + 0.1 × decisions + 1.0 × attempts`. These are declared arbitrary weights, not dollars, tokens, CPU time, or energy.

All same-time observations arrive before a decision. Timers and event triggers are coalesced into one decision. Periodic phase is fixed at zero. There is no capacity limit or action duration. Rates in the table give each seed/regime run equal weight. Bootstrap inference first averages paired policy differences over the five regimes for each seed, then resamples the 30 seed blocks 2,000 times with RNG seed 1729. Policies and correlated regimes stay paired. No hypothesis-test significance or population-level claim is made.

## Verification and engineering evidence

**28 tests passed** in the recorded run. [Full output](results/tests.txt) and [execution report](OVERNIGHT_REPORT.md) record the checks.

Tests cover analytical decay and partition invariance, transactional rollback, durable reopen, idempotent ingestion, conflicting IDs, monotonic time, fact revision/expiry, cancellation ordering, retry cooldown, duplicate-completion prevention, hand-calculated metrics, a baseline win, audit completeness, synthetic cost accounting, and byte-identical benchmark regeneration.

| Skill | Concrete evidence |
|---|---|
| AI engineering | Public observations separated from environment truth; shared policy and memory; explicit scheduling experiment |
| Python | Typed domain models, modular standard-library implementation, CLI, deterministic local RNGs |
| Databases | SQLite schema, transactions, persistent state, unique event identity, append-only application audit |
| Statistical evaluation | Matched environments, paired seed bootstrap, missing-metric conventions, counterexamples and trade-offs |
| Reliability | Fault rejection, rollback tests, restart persistence, reproducible outputs and source hashes |
| Long-horizon autonomy | Pending goals persist across events; delayed wakes, deadlines, cancellations, and retry state |

Browse [per-run measurements](results/runs.csv), [full summaries and intervals](results/summary.json), and the [SHA-256 provenance manifest](results/manifest.json). The manifest fingerprints Python sources/tests and deterministic CSV/JSON artifacts. SQLite files and test runtimes are not expected to be byte-identical. Reproducing on the recorded Python version is recommended; cross-version floating-point/serialization identity is not promised.

## Boundaries of v0.1

This is a **single-process, deterministic simulation**, not a deployed autonomous assistant. Goals are independent single-step actions spread over a short virtual horizon, not multi-day plans. There is no LLM, learned policy, vector search, tool execution, network service, human study, or spending.

The generator's disclosed readiness estimates favor a scheduler that can set timers. Five handcrafted regimes and one fixed periodic interval are not a representative task distribution. There is no held-out real workload, parameter sweep, or continuous-state ablation. Differences isolate the overall scheduling policies, **not** the causal contribution of decay, memory, or cognition. The main research question remains open.

Persistence is tested across clean database reopen and transaction failures, not power-loss fault injection or distributed execution. The audit is application-level history, not tamper-proof evidence. A benchmark process cannot resume halfway through a scenario. All agents retain memory, so this suite cannot establish a persistence advantage over memoryless agents.

[Future research](FUTURE_RESEARCH.md) describes explicitly **unimplemented** extensions. v0.1 stops here.

## Repository map

```text
continuum/model.py       Observations, private truth, analytical state
continuum/storage.py     SQLite memory, events, task state, receipts
continuum/agents.py      Shared policy and three wake-up strategies
continuum/scenarios.py   Seeded synthetic regimes
continuum/simulation.py  Virtual-time environment and metric accounting
continuum/benchmark.py   Paired summaries, intervals, artifact hashes
continuum/cli.py         Demo and benchmark commands
tests/                   Reliability and reproducibility checks
results/                 Actual benchmark evidence
```

# Future research — all unimplemented

These are proposed experiments, not v0.1 features or commitments. No integration, account connection, payment, matching service, or external action is implemented.

## Establish what actually causes improvements

Before adding models, compare adaptive scheduling with a simple readiness-only timer and a fixed-idle variant. Ablate activation decay and persistent memory independently. Sweep periodic interval, retry interval, timer phase, cost weights, readiness error, event density, and horizon. Evaluate on held-out generators and multi-step dependent goals. Predeclare primary metrics and operational budgets; compare completion at matched cost, not just unrestricted activity. Add deadline-penalized latency and opportunity-level action timing metrics so successful-only latency cannot conceal misses.

A useful falsification result would be a readiness-only timer matching the full adaptive policy. That would suggest the state dynamics add complexity without measurable value in the tested setting.

## LLM integration

Proposed: place an interchangeable planner behind a typed observation/action interface, while retaining the deterministic simulator as a test harness. Start with recorded responses, then separately authorized live experiments under explicit budgets. Keep actual model usage, token counts, latency, tool errors, and prices separate from the current synthetic cost weights.

Compare models and schedules on identical task instances; include repeated trials for stochastic outputs, prompt/version provenance, and hidden evaluation truth. Test whether a model correctly remembers revisions, abandons cancelled goals, recognizes uncertainty, and avoids unsupported interventions. Model text must never become an executable instruction without validation. An LLM backend alone would not demonstrate persistent intelligence.

## A2A / MCP experiments

Proposed: evaluate A2A-style agent-to-agent delegation and MCP-style tool/context adapters only after defining local, typed contracts. First use mock peers and tools, then sandbox integrations. Investigate how delayed responses, duplicate delivery, cancellation, and unavailable capabilities affect long-horizon task completion.

Requirements before live use: explicit capability grants, bounded delegation, stable request identities, traceable receipts, adversarial input tests, and separation between untrusted tool content and agent policy. Verify the then-current protocol specifications before selecting implementations. Neither protocol is integrated in v0.1.

## HTTP 402 / x402 payment research

Proposed: simulate a paid-resource boundary before implementing any HTTP 402/x402 flow. Compare whether paying for an additional tool or information source improves completion under a fixed budget. Use a fake ledger, deterministic quotes, and synthetic balances; measure utility per unit spent and failure recovery.

Questions include maximum spend per task, authorization expiry, duplicate-request accounting, rejected quotes, ambiguous settlement, and reconciling receipts. A later integration would require explicit user authorization, current protocol/security review, and an isolated test environment before any real transaction. There is no wallet, payment endpoint, token, signing key, or transaction code here.

## Privacy-preserving matchmaking

Proposed: study whether agents can find compatible collaborators or services while revealing only necessary attributes. Begin with synthetic profiles, an explicit threat model, and a plain local-matching baseline. Possible research tracks include selective attribute disclosure, private set intersection, and aggregate evaluation with differential privacy; none is selected or implemented.

Measure match quality alongside disclosure volume, inference attacks, false matches, consent revocation, retention, and auditability. Do not describe a design as privacy-preserving merely because it hides names or uses embeddings. Any cryptographic or differential-privacy claim would need a specified construction, assumptions, and independent verification. No personal profiles are ingested or shared in v0.1.

## Operational persistence

Proposed: checkpoint the complete simulation cursor and scheduler so interrupted experiments can resume exactly. Test crash injection, schema migration, concurrent access, replay, and reconciliation of uncertain external actions. Extend to a real event loop only after correctness is demonstrated under virtual time. These are prerequisites for evaluating unattended operation, not evidence supplied by the present clean-reopen tests.

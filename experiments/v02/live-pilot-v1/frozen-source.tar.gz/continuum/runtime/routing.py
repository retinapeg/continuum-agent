from dataclasses import dataclass


@dataclass(frozen=True)
class Route:
    provider: str
    model: str
    task_classes: tuple[str,...]
    reliability: float
    verified: bool


class Router:
    def __init__(self, routes, fixed=None):
        self.routes, self.fixed = routes, fixed

    def choose(self, task_class, attempt=0, prior_checkpoint=None, known_unsent=True):
        eligible = [r for r in self.routes if r.verified and task_class in r.task_classes]
        if attempt and not known_unsent:
            raise ValueError('outcome-unknown requests cannot be automatically routed again')
        if self.fixed:
            eligible = [r for r in eligible if (r.provider,r.model)==self.fixed]
        eligible.sort(key=lambda r:(-r.reliability,r.provider,r.model))
        if not eligible:
            raise ValueError('no verified configured route')
        chosen = eligible[min(attempt,len(eligible)-1)]
        return chosen, {'reason':'fixed_scientific_comparison' if self.fixed else 'verified_task_support_then_measured_reliability',
                        'candidates':[r.__dict__ for r in eligible], 'chosen':chosen.__dict__,
                        'fallback':bool(attempt),'attempt_index':attempt,'prior_checkpoint':prior_checkpoint}
